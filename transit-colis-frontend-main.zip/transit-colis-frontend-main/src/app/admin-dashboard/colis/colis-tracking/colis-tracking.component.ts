import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colis-tracking',
  templateUrl: './colis-tracking.component.html',
  styleUrls: ['./colis-tracking.component.scss']
})
export class ColisTrackingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
