const french_url="assets/properties/french.json";
const english_url="assets/properties/english.json";

export {
  french_url,
  english_url,
}
