export class Chauffeur{
  id: string;
  name: string;
  surname: string;
  telephone: string;
}
