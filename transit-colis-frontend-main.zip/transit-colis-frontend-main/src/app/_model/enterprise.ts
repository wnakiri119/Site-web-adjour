export class Enterprise {
  id: string;
  name: string;
  adresse: string;
  phone1: string;
  phone2: string;
  email: string;
}
