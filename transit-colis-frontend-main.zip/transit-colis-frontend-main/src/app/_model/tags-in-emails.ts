export class TagsInEmails{
  id: string;
  name: string;
  description: string;
  whatToDo: number;
  saveOptional: boolean;
}
