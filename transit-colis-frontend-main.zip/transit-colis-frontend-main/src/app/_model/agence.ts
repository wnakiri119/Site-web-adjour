import {Ville} from "./ville";

export class Agence {
  id: string;
  code: string;
  name: string;
  ville: Ville;
}
