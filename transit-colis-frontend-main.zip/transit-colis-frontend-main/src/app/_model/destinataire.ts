export class Destinataire {
  id: string;
  name: string;
  surname: string;
  telephone: string;
  email: string;
  relationClientDestinataire: string;
  dateCreated: string;
  dateLastUpdate: string;
}
