const smaller_role_employer = 'GUICHETIER'

export {
  smaller_role_employer
}
