import {ModelMail} from "./modelMail";

export class GroupModelEmail {
  id: string;
  modelEmails: ModelMail[];
}
