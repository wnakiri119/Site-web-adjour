export class Vehicule{
  id: string;
  imatriculation: string;
  marque: string;
  model: string;
}
