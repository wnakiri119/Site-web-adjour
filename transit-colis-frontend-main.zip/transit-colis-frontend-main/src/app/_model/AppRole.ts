export class AppRole {
  id: string;
  name: string;
  description: string;
}
