export class StatusExpedition {
  id: string
  value: string;
  description: string;
}
