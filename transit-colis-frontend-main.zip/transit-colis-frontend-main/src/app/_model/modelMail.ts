export class ModelMail{
  id: string;
  subject: string;
  message: string;
}
