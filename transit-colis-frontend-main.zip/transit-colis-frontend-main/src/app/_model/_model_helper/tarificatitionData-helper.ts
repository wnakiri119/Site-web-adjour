import {Tarification} from "../tarification";
import {Adresse} from "../adresse";

export class TarificatitionDataHelper{
  tarification: Tarification;
  adresseDestination: Adresse[];
  adresseSource: Adresse[];
}
