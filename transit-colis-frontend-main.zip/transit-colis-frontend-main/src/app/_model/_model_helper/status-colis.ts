export class StatusColis {
  id: number
  value: string;
  description: string;
  indexForm: number;
}
