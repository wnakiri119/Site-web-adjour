import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expedition-state-add',
  templateUrl: './expedition-state-add.component.html',
  styleUrls: ['./expedition-state-add.component.scss']
})
export class ExpeditionStateAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
