import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-param',
  templateUrl: './message-param.component.html',
  styleUrls: ['./message-param.component.scss']
})
export class MessageParamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
