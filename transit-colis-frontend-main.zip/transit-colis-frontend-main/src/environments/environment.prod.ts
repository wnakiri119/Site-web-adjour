export const environment = {
  production: true,
  BASE_URL : 'http://88.198.209.182:8080/site-vitrine',
  API_URL : 'http://88.198.209.182:8080/site-vitrine/api/v1',
  API_URL_REPOSITORY : 'http://88.198.209.182:8080/site-vitrine/api',

  /*BASE_URL : 'http://localhost:8182',
  API_URL : 'http://localhost:8182/api/v1',
  API_URL_REPOSITORY : 'http://localhost:8182/api',*/
};
